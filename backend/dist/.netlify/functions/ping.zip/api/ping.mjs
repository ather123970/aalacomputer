
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// api/_lib/cors.js
function withCors(req, res) {
  const DEFAULT_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost",
    "https://aalacomputerkarachi.vercel.app",
    "https://aalacomputer.com"
  ];
  const envVal = process.env.FRONTEND_ORIGINS || process.env.FRONTEND_ORIGIN || "";
  const FRONTEND_ORIGINS = (envVal ? envVal.split(",") : DEFAULT_ORIGINS).map((s) => (s || "").trim()).filter(Boolean);
  const ALLOW_ANY_ORIGIN = String(process.env.ALLOW_ANY_ORIGIN || "").toLowerCase() === "true";
  const reqOrigin = req.headers && req.headers.origin;
  function setCommonHeaders(originValue) {
    if (originValue) {
      res.setHeader("Access-Control-Allow-Origin", originValue);
    }
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
  }
  if (ALLOW_ANY_ORIGIN) {
    if (reqOrigin) {
      setCommonHeaders(reqOrigin);
    } else {
      setCommonHeaders("*");
    }
    if (req.method === "OPTIONS") return res.status(204).end();
    return;
  }
  if (FRONTEND_ORIGINS.length > 0 && FRONTEND_ORIGINS.indexOf("*") === -1) {
    if (reqOrigin) {
      if (FRONTEND_ORIGINS.indexOf(reqOrigin) !== -1) {
        setCommonHeaders(reqOrigin);
      } else {
        setCommonHeaders();
        if (req.method === "OPTIONS") {
          return res.status(403).end();
        }
      }
    } else {
      setCommonHeaders(FRONTEND_ORIGINS[0]);
    }
  } else {
    setCommonHeaders(reqOrigin || "*");
  }
  if (req.method === "OPTIONS") return res.status(204).end();
}

// api/ping.js
function handler(req, res) {
  withCors(req, res);
  if (req.method === "OPTIONS") return res.status(200).end();
  res.status(200).json({ ok: true, ts: Date.now() });
}
export {
  handler as default
};
