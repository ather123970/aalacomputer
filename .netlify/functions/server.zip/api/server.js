var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var server_exports = {};
__export(server_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(server_exports);
var import_serverless_http = __toESM(require("serverless-http"), 1);
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
var import_module = require("module");
const import_meta = {};
const __filename = (0, import_url.fileURLToPath)(import_meta.url);
const __dirname = import_path.default.dirname(__filename);
const backendIndex = import_path.default.join(__dirname, "..", "backend", "index.cjs");
let appModule = null;
let app = null;
try {
  const requireFromThis = (0, import_module.createRequire)(import_meta.url);
  appModule = requireFromThis(backendIndex);
  app = appModule && (appModule.app || appModule.default || appModule);
} catch (e) {
  try {
    const url = `file://${backendIndex}`;
    appModule = import(url);
    app = appModule && (appModule.app || appModule.default || appModule);
  } catch (err) {
    console.error("Failed to load backend app for serverless (createRequire and dynamic import failed):", err);
    throw err;
  }
}
if (!app) {
  const err = new Error("Backend app not found for serverless wrapper");
  console.error(err);
  throw err;
}
const handler = (0, import_serverless_http.default)(app);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
